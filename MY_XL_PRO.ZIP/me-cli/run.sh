#!/bin/bash
# Script untuk menjalankan me-cli dengan virtual environment

# Aktivasi virtual environment
source venv/bin/activate

# Jalankan aplikasi
python main_encrypted.py

# Deaktivasi virtual environment setelah selesai
deactivate