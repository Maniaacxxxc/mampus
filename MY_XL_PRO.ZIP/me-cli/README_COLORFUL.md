# 🌈 MY XL CLI - Enhanced Colorful Edition

![MY XL Logo](https://img.shields.io/badge/MY-XL-blue?style=for-the-badge&logo=data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==)

CLI client untuk provider internet mobile Indonesia dengan tampilan yang lebih menarik dan berwarna!

## ✨ Fitur Baru Tampilan

- 🎨 **Interface Berwarna**: Tampilan menu dengan warna-warna menarik
- 🏷️ **Logo MY XL**: Logo ASCII art yang colorful di header
- 📱 **Icon Menu**: Setiap menu dilengkapi dengan emoji yang relevan
- 🎯 **Status Visual**: Pesan sukses, error, dan warning dengan indikator visual
- 📦 **Box Design**: Kotak-kotak cantik untuk section penting
- 🌈 **Gradient Effects**: Separator dan garis dengan warna gradasi

## 🚀 Cara Menjalankan

```bash
cd /path/to/me-cli
./run.sh
```

## 🎮 Menu Utama

- **👤 Login/Ganti Akun** - Kelola akun MY XL Anda
- **📦 Lihat Paket Saya** - Cek paket yang sudah dimiliki
- **🔥 Beli Paket HOT** - Paket populer dengan harga terbaik
- **🔥 Beli Paket HOT-2** - Koleksi paket premium terbaru
- **👨‍👩‍👧‍👦 Beli Paket Family Code** - Beli berdasarkan family code
- **📊 Riwayat Transaksi** - Lihat history pembelian
- **🧪 Test Purchase Family Code** - Mode testing pembelian
- **⭐ Bookmark Paket** - Paket favorit yang disimpan
- **🚪 Tutup Aplikasi** - Keluar dari aplikasi

## 🎨 Kode Warna

- 🔵 **Biru** (`BRIGHT_BLUE`) - Menu utama dan navigasi
- 🔴 **Merah** (`BRIGHT_RED`) - Paket HOT dan peringatan
- 🟡 **Kuning** (`BRIGHT_YELLOW`) - Harga dan informasi penting
- 🟢 **Hijau** (`BRIGHT_GREEN`) - Status sukses dan konfirmasi
- 🟣 **Magenta** (`BRIGHT_MAGENTA`) - Fitur khusus dan highlight
- 🔵 **Cyan** (`BRIGHT_CYAN`) - Informasi dan panduan

## 📋 Status Messages

- **✅ Success** - Pesan berhasil dengan tanda centang hijau
- **❌ Error** - Pesan error dengan tanda silang merah  
- **⚠️ Warning** - Peringatan dengan tanda seru kuning
- **ℹ️ Info** - Informasi dengan tanda info biru

## 🔧 Instalasi

### Persyaratan
- Python 3.8+
- Virtual environment (venv)
- API Key dari [@fykxt_bot](https://t.me/fykxt_bot)

### Langkah Instalasi
1. Clone repository
2. Jalankan `chmod +x run.sh`
3. Eksekusi `./run.sh`
4. Masukkan API Key saat diminta

## 🎯 Fitur Tambahan

### 🔐 Multi-Account Support
- Simpan multiple akun MY XL
- Switch antar akun dengan mudah
- Indikator akun aktif yang jelas

### 📌 Bookmark System  
- Simpan paket favorit
- Akses cepat ke paket yang sering dibeli
- Kelola bookmark dengan mudah

### 🔥 Hot Packages
- Paket terpopuler dengan UI menarik
- Dua kategori HOT packages
- Informasi lengkap dengan visual yang jelas

## 🎨 Customization

File `app/colors.py` berisi semua definisi warna dan styling. Anda dapat memodifikasi:
- Warna tema
- Style pesan
- Format tampilan
- Icon dan emoji

## 📱 Screenshots Preview

```
███╗   ███╗██╗   ██╗    ██╗  ██╗██╗     
████╗ ████║╚██╗ ██╔╝    ╚██╗██╔╝██║     
██╔████╔██║ ╚████╔╝      ╚███╔╝ ██║     
██║╚██╔╝██║  ╚██╔╝       ██╔██╗ ██║     
██║ ╚═╝ ██║   ██║        ██╔╝ ██╗███████╗
╚═╝     ╚═╝   ╚═╝        ╚═╝  ╚═╝╚══════╝

🌟 MY XL CLI - Paket Internet & Pulsa 🌟
════════════════════════════════════════════════════════════

┌──────────────────┐
│ 📱 INFORMASI AKUN │
└──────────────────┘

📞 Nomor: 628xxxxxxxxx
💰 Pulsa: Rp 50,000
⏰ Masa Aktif: 2025-12-31 23:59:59

┌──────────────┐
│ 🎮 MENU UTAMA │
└──────────────┘

 1. 👤 Login/Ganti Akun
 2. 📦 Lihat Paket Saya  
 3. 🔥 Beli Paket 🔥 HOT 🔥
```

## 🐛 Troubleshooting

### API Key Issues
- Pastikan API key valid dari bot Telegram
- Cek saldo/credit API key
- Verifikasi koneksi internet

### Display Issues  
- Pastikan terminal mendukung Unicode dan ANSI colors
- Gunakan terminal modern (iTerm2, Windows Terminal, etc.)
- Set encoding ke UTF-8

## 🤝 Contributing

Kontribusi sangat diterima! Silakan:
1. Fork repository
2. Buat branch fitur baru
3. Commit perubahan
4. Push ke branch
5. Buat Pull Request

## 📝 Changelog

### v2.0 - Colorful Edition
- ✨ Tambah interface berwarna
- 🎨 Logo MY XL ASCII art
- 📱 Icon dan emoji untuk setiap menu
- 🎯 Status messages dengan visual indicator
- 📦 Box design untuk section penting
- 🌈 Separator dan styling yang menarik

### v1.0 - Original
- Fitur dasar CLI untuk MY XL
- Multi-account support
- Bookmark system
- HOT packages

## 📞 Contact

- **Developer**: Original by [@purplemashu](https://github.com/purplemashu)  
- **Enhanced UI**: Colorful edition with improved UX
- **Support**: [GitHub Issues](https://github.com/purplemashu/me-cli/issues)

---

**🌟 Nikmati pengalaman MY XL CLI yang lebih colorful dan user-friendly! 🌟**