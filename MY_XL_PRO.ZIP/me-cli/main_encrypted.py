#!/usr/bin/env python3
"""
ME CLI - Encrypted Main Module
Generated automatically - Do not edit manually
"""
import base64
import zlib
import sys
import os

# Encrypted payload
ENCRYPTED_DATA = """eNrdWV9v20YSf9enmNAwTLWO4rptiggIDoqj2EIsxbBl9AzDINbkStqK/8BdxhF8Bu75em3apn0p0KYPd5c2QO96b/08+QKXj3CzS1Lin6VlO/d0fBDJ5c5vdmd+szO7GkWBB04gqP8UmBcGkQA3II6VNDUauRezCY1G2ofPeGMkRUkYtjzqx7wVC+ZmELZLSWRxO6LUX4eQxJwuutsuo75oUX/M6VzivZrvm1mHMRWWYDRi/thi/igoqw/JDB9E1p1PgjNLRMTnxBYs8K0J4yKIZgsxTqOnzKYtEotJJtXB557PBfFtWlZwGgRTj0TTgoas0ZJ9yhLEtoO4NKS0Tds/JPaUjGnWf0SFPbG8mZW283VlhOzNOp1ZI+Ixd1bGmQRFnfiu9K0XXzertuBowWiWCeMLRS+qNssLnIpJwjiyJ4TPR5y964ZmB24Q8YW7Gw4dJePxCPPVgMwwCkbMpc12A/DKk8hsqib6LGQRdSwiLEfAfXCIoIJ5tCXVyAd0nRdmOMfGKXGlK62FnHHSbHERjWRn01g9ur3q3V51YHWnvdpvrx4YiR71swKd1IE95FvkEckjOGNIl2QyqleIjBTIg2em8fbli39Db/DoyX6/c9CDzuPDgbEOW6pv68F+b3tnaG3vd7uD5kLSzD9LXltMUE9h/QiDwAsihMjms+bH3imN1k7KqFtHnUGzHulzGLKQItDIOJ9j8fgUbctCFR1iFtK1kwswK99Rn8Uc/NaszOWou7v75NN6vd/8Bnuxy4lSvB/CAjv1C6LWGKgW88t/wV7A/LxRwkB6QPaqGqbf2e4Ohp06vDfPf4M+4QQ6U8FGCFogWBns053esNusOi9lSx8pnKcHEN8BZge+hihf/hP63cEhHA47/U7FBg92D7t1HJGBko7+AxQ0doMx8+9sE18wnEUsLYP4X//NWD76HNSmgmITImCPTKmAAzIjCdSLfxhL6ZZD+lBKPaAuS4Hevvz277DzZKgeEkR1LyLudx/WAX5UA3h783JIDTtzqB+XUB+p5QohHJpa8Oc3f/4Cb78kt1fJrWoLHcNyeu5KtH12huYUMFT5aMpZatm/XIH9OaxPpNjxEBe5EwysdOmtDPzV66uYokbFxoayS5bqlG1ky5tfv7oWC+7dk1LDWMQhdEKXTUk26e9fL3V+7hmzT0gigpkbg/U7OYa7G9pxNBpJLpExeB8NHVOVYGRuMdN8on7OJrhmqO9Jo7xkhfCUWlikRCibrwFaMuHmPuPQ5lIrgKE3phji/ryNjQpgjIOPuXgQ+Dlt8krXP9QmFaRvZkEzCZk1pbP1POCxIYIp9blxcmwwx1IvmNB00FZE5dyxWkIlaZucjWnMPxh6wcUSWJbMZdGiaOElXZctzM0knWDadL0JYqVEOc8meW07YPrCvIUDyI/n2EjfpGQhwRknFWmZE68gv0igJYyiVeZJCiENmcIEb8PgTgf+hMmZRurZqJdHZi3GJBH2u3ud3kOjyCt5ZUVyzv75uvk6TmhqwRE0ryPhhmzB6NyoithxFGEJaSkLaGULPfQgBfON5vY7L4hezG15LpVcGEtJimDnFV1GUmUZ7aJR0taT9apAkUntlHv1HXOUac/dqumeRh92qkR1fe98sdvWRLVGcmFdlFi8FDpeNIoBoq/cS0aWSKoYok5WvDGXTUDKtEFfomAR5jv3jdISY08CphZM5ocxcqb0GcMj64HB8YEmLHAvSW2BFpDetBJnIlxlU2ZWySdjTyNd1SGvQnjxUvrQwVT1UZdTPXiSH89IJClgeXxsGkPmkCkQh4BKOTOCK77DQmVmjLAYxmRMXLS4F+OKLvu0jKYmSgMsIH3MmsWBFO26qbFrZZdq3hD8Q53T8vvVEnBZ/qNl8ptLAD7WAGj2oFWGpzV9TcUID7q7PdjrPO4O4VGn39s9gq0nD7u1haReSa3yXHi9+EFuZuLplPiQbL/R8g6FUFW4ihlIG+YjP05x8m19RbdMT67gBFMxbO3evTXA+ImnuNwI4javF9qKRQrUUsOti/E0FAtd0W1YauqDRcs6eelPUcwc8OVEuVvHNM15083TbVnrJ+9Iz1evYdg9GMLe4f7WTuegeykZ0x3DTbn45vuf/vP7c4C+dJLADYusQ28DkczElUiyD5dUXJFSbjqYpbw8Z29db0T/T+ysZs1fYTv2le0cagczSLn7BzBnd3zddGQc188GSWclQLm5tNzgTO5v5KDXZmtLHfz8d+XgPXm0i64U1CUTeWckhDDxMI4X0xtuUpl706Gqk2MLo4nHajdwrRFXDiPzEb6+MMN6Rc3lgYh75Jr4L5wGL8k2WmJcKZ5z1Pj6cxhiNe0RkBvsCSRuQO3jccqY/hH8cRe2dnu3brbav33515dwQLyQMPgsxhu4ZMxugWy/cozyGW/RZ0yYG5fbRGhMElGe7SIT2pvLy65smdX21C69+q6GUWmuWxI/44HfctBA3IzkST3zHdyX3N/UlFopg/ciSeiuPGMHEczXg1arpQ0Ezi81HdeYrnJ+X6Gkrs5M5kOjKIiSClOV7EgloSrNp8RlTgsOGDJNEswOThNOaMtKFVk5tVWVKzAI5H9O5aOUd6jZr1yvv2Otfpn9/hc1egMnYlk+8ahlKSdbyY7LSn2Nbl2oT0660n9JbBoKeExnpwGJnJ6kQRSHYtG5nMZ1C8tj6sYkwtQcMSDpER4mIH+MTt8Skfv+1tL4X7aW1Cwji4VpJZtLV93k/y+EQ2r0ldxURkbHB8VZCGx1KOC04ZxeYCj9F9AFt1I="""

def decrypt_and_run():
    """Decrypt dan jalankan main code"""
    try:
        # Decode from base64
        compressed_data = base64.b64decode(ENCRYPTED_DATA.encode('ascii'))
        
        # Decompress
        original_code = zlib.decompress(compressed_data).decode('utf-8')
        
        # Set __file__ untuk compatibility
        globals()['__file__'] = os.path.join(os.path.dirname(__file__), 'main.py')
        
        # Execute the decrypted code
        exec(original_code, globals())
        
    except Exception as e:
        print(f"❌ Error menjalankan aplikasi: {e}")
        sys.exit(1)

if __name__ == "__main__":
    decrypt_and_run()
