#!/usr/bin/env python3
"""
ME CLI Smart Launcher
Auto-detect dan jalankan versi yang tersedia
"""

import os
import sys

def main():
    print("🚀 ME CLI Smart Launcher")
    print("="*50)
    
    # Check available versions
    has_original = os.path.exists('main.py')
    has_encrypted = os.path.exists('main_encrypted.py')
    
    if not has_original and not has_encrypted:
        print("❌ Error: Tidak ada main.py atau main_encrypted.py")
        sys.exit(1)
    
    # Auto-select version
    if has_encrypted:
        print("🔐 Menjalankan versi encrypted...")
        try:
            import main_encrypted
        except Exception as e:
            print(f"❌ Error running encrypted version: {e}")
            if has_original:
                print("🔄 Fallback ke versi original...")
                import main
            else:
                sys.exit(1)
    else:
        print("📝 Menjalankan versi original...")
        import main

if __name__ == "__main__":
    main()