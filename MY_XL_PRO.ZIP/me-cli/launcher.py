#!/usr/bin/env python3
"""
ME CLI Launcher - Entry Point
Jalankan: python launcher.py
"""

if __name__ == "__main__":
    try:
        # Import dan jalankan encrypted main
        import main_encrypted
    except ImportError as e:
        print("❌ Error: File main_encrypted.py tidak ditemukan")
        print("💡 Pastikan sudah menjalankan encrypt_main.py terlebih dahulu")
        exit(1)
    except Exception as e:
        print(f"❌ Error menjalankan aplikasi: {e}")
        exit(1)
