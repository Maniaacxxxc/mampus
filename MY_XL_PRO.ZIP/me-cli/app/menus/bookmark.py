from app.menus.package import show_package_details
from app.service.auth import AuthInstance
from app.menus.util import clear_screen, pause
from app.service.bookmark import BookmarkInstance
from app.client.engsel import get_family
from app.colors import *

def show_bookmark_menu():
    api_key = AuthInstance.api_key
    tokens = AuthInstance.get_active_tokens()
    
    in_bookmark_menu = True
    while in_bookmark_menu:
        clear_screen()
        print_box("⭐ BOOKMARK PAKET", Colors.BRIGHT_CYAN)
        print_colored("📌 Paket favorit yang telah Anda simpan", Colors.BRIGHT_WHITE)
        print_separator("═", 60, Colors.BRIGHT_CYAN)
        print()
        
        bookmarks = BookmarkInstance.get_bookmarks()
        if not bookmarks or len(bookmarks) == 0:
            print(warning_msg("Tidak ada bookmark tersimpan."))
            pause()
            return None
        
        for idx, bm in enumerate(bookmarks):
            print(f"{Colors.BOLD}{Colors.BRIGHT_CYAN}{idx + 1:>2}.{Colors.RESET} {Colors.BRIGHT_WHITE}{bm['family_name']}{Colors.RESET}")
            print(f"    {Colors.BRIGHT_YELLOW}└─ {bm['variant_name']} - {bm['option_name']}{Colors.RESET}")
            if idx < len(bookmarks) - 1:
                print_colored("    ⋯", Colors.DIM)
        
        print()
        print(menu_item("00", "Kembali ke Menu Utama", "🏠", Colors.BRIGHT_BLUE))
        print(menu_item("000", "Hapus Bookmark", "🗑️", Colors.BRIGHT_RED))
        print()
        print_separator("─", 60, Colors.DIM)
        print_colored("📌 Pilih bookmark (nomor): ", Colors.BRIGHT_CYAN, end="")
        choice = input("")
        if choice == "00":
            in_bookmark_menu = False
            return None
        elif choice == "000":
            del_choice = input("Masukan nomor bookmark yang ingin dihapus: ")
            if del_choice.isdigit() and 1 <= int(del_choice) <= len(bookmarks):
                del_bm = bookmarks[int(del_choice) - 1]
                BookmarkInstance.remove_bookmark(
                    del_bm["family_code"],
                    del_bm["is_enterprise"],
                    del_bm["variant_name"],
                    del_bm["order"],
                )
            else:
                print("Input tidak valid. Silahkan coba lagi.")
                pause()
            continue
        if choice.isdigit() and 1 <= int(choice) <= len(bookmarks):
            selected_bm = bookmarks[int(choice) - 1]
            family_code = selected_bm["family_code"]
            is_enterprise = selected_bm["is_enterprise"]
            
            family_data = get_family(api_key, tokens, family_code, is_enterprise)
            if not family_data:
                print("Gagal mengambil data family.")
                pause()
                continue
            
            package_variants = family_data["package_variants"]
            option_code = None
            for variant in package_variants:
                if variant["name"] == selected_bm["variant_name"]:
                    selected_variant = variant
                    
                    package_options = selected_variant["package_options"]
                    for option in package_options:
                        if option["order"] == selected_bm["order"]:
                            selected_option = option
                            option_code = selected_option["package_option_code"]
                            break
            
            if option_code:
                print(f"{option_code}")
                show_package_details(api_key, tokens, option_code, is_enterprise)            
            
        else:
            print("Input tidak valid. Silahkan coba lagi.")
            pause()
            continue