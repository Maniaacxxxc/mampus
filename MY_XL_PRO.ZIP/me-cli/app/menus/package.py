import json
import sys

import requests
from app.service.auth import AuthInstance
from app.client.engsel import get_family, get_package, get_addons, get_package_details, send_api_request
from app.service.bookmark import BookmarkInstance
from app.client.purchase import settlement_bounty, settlement_loyalty
from app.menus.util import clear_screen, pause, display_html
from app.client.qris import show_qris_payment
from app.client.ewallet import show_multipayment
from app.client.balance import settlement_balance
from app.type_dict import PaymentItem
from app.colors import *


def show_package_details(api_key, tokens, package_option_code, is_enterprise, option_order = -1):
    clear_screen()
    print_box("📦 DETAIL PAKET", Colors.BRIGHT_BLUE)
    package = get_package(api_key, tokens, package_option_code)
    # print(f"[SPD-202]:\n{json.dumps(package, indent=1)}")
    if not package:
        print(error_msg("Gagal memuat detail paket."))
        pause()
        return False

    price = package["package_option"]["price"]
    detail = display_html(package["package_option"]["tnc"])
    validity = package["package_option"]["validity"]

    option_name = package.get("package_option", {}).get("name","") #Vidio
    family_name = package.get("package_family", {}).get("name","") #Unlimited Turbo
    variant_name = package.get("package_detail_variant", "").get("name","") #For Xtra Combo
    option_name = package.get("package_option", {}).get("name","") #Vidio
    
    title = f"{family_name} - {variant_name} - {option_name}".strip()
    
    token_confirmation = package["token_confirmation"]
    ts_to_sign = package["timestamp"]
    payment_for = package["package_family"]["payment_for"]
    
    payment_items = [
        PaymentItem(
            item_code=package_option_code,
            product_type="",
            item_price=price,
            item_name=f"{variant_name} {option_name}".strip(),
            tax=0,
            token_confirmation=token_confirmation,
        )
    ]
    
    print()
    print(info_item("📦 Nama", title, Colors.BRIGHT_CYAN))
    print(info_item("💰 Harga", f"Rp {price:,}", Colors.BRIGHT_GREEN))
    print(info_item("💳 Payment For", payment_for, Colors.BRIGHT_YELLOW))
    print(info_item("⏰ Masa Aktif", validity, Colors.BRIGHT_WHITE))
    print(info_item("🎯 Point", package['package_option']['point'], Colors.BRIGHT_MAGENTA))
    print(info_item("📋 Plan Type", package['package_family']['plan_type'], Colors.BRIGHT_BLUE))
    print()
    print_separator("─", 60, Colors.BRIGHT_CYAN)
    benefits = package["package_option"]["benefits"]
    if benefits and isinstance(benefits, list):
        print_colored("🎁 BENEFITS:", Colors.BOLD + Colors.BRIGHT_GREEN)
        print()
        for benefit in benefits:
            print_separator("─", 50, Colors.DIM)
            print(info_item("📋 Name", benefit['name'], Colors.BRIGHT_YELLOW))
            print(info_item("🔢 Item ID", benefit['item_id'], Colors.DIM))
            data_type = benefit['data_type']
            if data_type == "VOICE" and benefit['total'] > 0:
                print(info_item("📞 Total", f"{benefit['total']/60:.0f} menit", Colors.BRIGHT_GREEN))
            elif data_type == "TEXT" and benefit['total'] > 0:
                print(info_item("💬 Total", f"{benefit['total']} SMS", Colors.BRIGHT_BLUE))
            elif data_type == "DATA" and benefit['total'] > 0:
                if benefit['total'] > 0:
                    quota = int(benefit['total'])
                    # It is in byte, make it in GB
                    if quota >= 1_000_000_000:
                        quota_gb = quota / (1024 ** 3)
                        print(info_item("📊 Quota", f"{quota_gb:.2f} GB", Colors.BRIGHT_CYAN))
                    elif quota >= 1_000_000:
                        quota_mb = quota / (1024 ** 2)
                        print(info_item("📊 Quota", f"{quota_mb:.2f} MB", Colors.BRIGHT_CYAN))
                    elif quota >= 1_000:
                        quota_kb = quota / 1024
                        print(info_item("📊 Quota", f"{quota_kb:.2f} KB", Colors.BRIGHT_CYAN))
                    else:
                        print(info_item("📊 Total", f"{quota}", Colors.BRIGHT_CYAN))
            elif data_type not in ["DATA", "VOICE", "TEXT"]:
                print(info_item("📊 Total", f"{benefit['total']} ({data_type})", Colors.BRIGHT_WHITE))
            
            if benefit["is_unlimited"]:
                print(info_item("♾️ Unlimited", "Yes", Colors.BRIGHT_MAGENTA))
        print()
        print_separator("═", 60, Colors.BRIGHT_CYAN)
    addons = get_addons(api_key, tokens, package_option_code)
    

    bonuses = addons.get("bonuses", [])
    
    # Pick 1st bonus if available, need more testing
    # if len(bonuses) > 0:
    #     payment_items.append(
    #         PaymentItem(
    #             item_code=bonuses[0]["package_option_code"],
    #             product_type="",
    #             item_price=0,
    #             item_name=bonuses[0]["name"],
    #             tax=0,
    #             token_confirmation="",
    #         )
    #     )
    
    # Pick all bonuses, need more testing
    # for bonus in bonuses:
    #     payment_items.append(
    #         PaymentItem(
    #             item_code=bonus["package_option_code"],
    #             product_type="",
    #             item_price=0,
    #             item_name=bonus["name"],
    #             tax=0,
    #             token_confirmation="",
    #         )
    #     )

    print(f"Addons:\n{json.dumps(addons, indent=2)}")
    print("-------------------------------------------------------")
    print(f"SnK MyXL:\n{detail}")
    print("-------------------------------------------------------")
    
    in_package_detail_menu = True
    while in_package_detail_menu:
        print("Options:")
        print("1. Beli dengan Pulsa")
        print("2. Beli dengan E-Wallet")
        print("3. Bayar dengan QRIS")
        print("4. Pulsa + Decoy XCP")
        
        # Sometimes payment_for is empty, so we set default to BUY_PACKAGE
        if payment_for == "":
            payment_for = "BUY_PACKAGE"
        
        if payment_for == "REDEEM_VOUCHER":
            print("5. Ambil sebagai bonus (jika tersedia)")
            print("6. Beli dengan Poin (jika tersedia)")
        
        if option_order != -1:
            print("0. Tambah ke Bookmark")
        print("00. Kembali ke daftar paket")

        choice = input("Pilihan: ")
        if choice == "00":
            return False
        if choice == "0" and option_order != -1:
            # Add to bookmark
            success = BookmarkInstance.add_bookmark(
                family_code=package.get("package_family", {}).get("package_family_code",""),
                family_name=package.get("package_family", {}).get("name",""),
                is_enterprise=is_enterprise,
                variant_name=variant_name,
                option_name=option_name,
                order=option_order,
            )
            if success:
                print("Paket berhasil ditambahkan ke bookmark.")
            else:
                print("Paket sudah ada di bookmark.")
            pause()
            continue
        
        if choice == '1':
            settlement_balance(
                api_key,
                tokens,
                payment_items,
                payment_for,
                True
            )
            input("Silahkan cek hasil pembelian di aplikasi MyXL. Tekan Enter untuk kembali.")
            return True
        elif choice == '2':
            show_multipayment(
                api_key,
                tokens,
                payment_items,
                payment_for,
                True,
            )
            input("Silahkan lakukan pembayaran & cek hasil pembelian di aplikasi MyXL. Tekan Enter untuk kembali.")
            return True
        elif choice == '3':
            show_qris_payment(
                api_key,
                tokens,
                payment_items,
                payment_for,
                True,
            )
            input("Silahkan lakukan pembayaran & cek hasil pembelian di aplikasi MyXL. Tekan Enter untuk kembali.")
            return True
        elif choice == '4':
            # Balance; Decoy XCP
            url = "https://me.mashu.lol/pg-decoy-xcp.json"
            
            response = requests.get(url, timeout=30)
            if response.status_code != 200:
                print("Gagal mengambil data decoy package.")
                pause()
                return None
            
            decoy_data = response.json()
            decoy_package_detail = get_package_details(
                api_key,
                tokens,
                decoy_data["family_code"],
                decoy_data["variant_code"],
                decoy_data["order"],
                decoy_data["is_enterprise"],
                decoy_data["migration_type"],
            )

            payment_items.append(
                PaymentItem(
                    item_code=decoy_package_detail["package_option"]["package_option_code"],
                    product_type="",
                    item_price=decoy_package_detail["package_option"]["price"],
                    item_name=decoy_package_detail["package_option"]["name"],
                    tax=0,
                    token_confirmation=decoy_package_detail["token_confirmation"],
                )
            )

            overwrite_amount = price + decoy_package_detail["package_option"]["price"]
            res = settlement_balance(
                api_key,
                tokens,
                payment_items,
                "BUY_PACKAGE",
                False,
                overwrite_amount,
            )
            
            if res and res.get("status", "") != "SUCCESS":
                error_msg = res.get("message", "Unknown error")
                if "Bizz-err.Amount.Total" in error_msg:
                    error_msg_arr = error_msg.split("=")
                    valid_amount = int(error_msg_arr[1].strip())
                    
                    print(f"Adjusted total amount to: {valid_amount}")
                    res = settlement_balance(
                        api_key,
                        tokens,
                        payment_items,
                        "BUY_PACKAGE",
                        False,
                        valid_amount,
                    )
                    if res and res.get("status", "") == "SUCCESS":
                        print("Purchase successful!")
            else:
                print("Purchase successful!")
            pause()
            return True
        elif choice == '5':
            settlement_bounty(
                api_key=api_key,
                tokens=tokens,
                token_confirmation=token_confirmation,
                ts_to_sign=ts_to_sign,
                payment_target=package_option_code,
                price=price,
                item_name=variant_name
            )
            input("Silahkan lakukan pembayaran & cek hasil pembelian di aplikasi MyXL. Tekan Enter untuk kembali.")
            return True
        elif choice == '6':
            settlement_loyalty(
                api_key=api_key,
                tokens=tokens,
                token_confirmation=token_confirmation,
                ts_to_sign=ts_to_sign,
                payment_target=package_option_code,
                price=price,
            )
            input("Silahkan lakukan pembayaran & cek hasil pembelian di aplikasi MyXL. Tekan Enter untuk kembali.")
            return True
        else:
            print("Purchase cancelled.")
            return False
    pause()
    sys.exit(0)

def get_packages_by_family(
    family_code: str,
    is_enterprise: bool | None = None,
    migration_type: str | None = None
):
    api_key = AuthInstance.api_key
    tokens = AuthInstance.get_active_tokens()
    if not tokens:
        print("No active user tokens found.")
        pause()
        return None
    
    packages = []
    
    data = get_family(
        api_key,
        tokens,
        family_code,
        is_enterprise,
        migration_type
    )
    
    if not data:
        print("Failed to load family data.")
        pause()
        return None
    price_currency = "Rp"
    rc_bonus_type = data["package_family"].get("rc_bonus_type", "")
    if rc_bonus_type == "MYREWARDS":
        price_currency = "Poin"
    
    in_package_menu = True
    while in_package_menu:
        clear_screen()
        print_box("👨‍👩‍👧‍👦 FAMILY PACKAGES", Colors.BRIGHT_MAGENTA)
        print()       
        print(info_item("📦 Family Name", data['package_family']['name'], Colors.BRIGHT_CYAN))
        print(info_item("🔢 Family Code", family_code, Colors.BRIGHT_YELLOW))
        print(info_item("📋 Family Type", data['package_family']['package_family_type'], Colors.BRIGHT_WHITE))
        print(info_item("📊 Variant Count", len(data['package_variants']), Colors.BRIGHT_GREEN))
        print()
        print_colored("📦 PAKET TERSEDIA:", Colors.BOLD + Colors.BRIGHT_BLUE)
        print_separator("═", 60, Colors.BRIGHT_MAGENTA)
        print()
        
        package_variants = data["package_variants"]
        
        option_number = 1
        variant_number = 1
        
        for variant in package_variants:
            variant_name = variant["name"]
            variant_code = variant["package_variant_code"]
            print(f"{Colors.BOLD}{Colors.BRIGHT_CYAN}📱 Variant {variant_number}: {Colors.BRIGHT_WHITE}{variant_name}{Colors.RESET}")
            print(f"{Colors.DIM}   Code: {variant_code}{Colors.RESET}")
            for option in variant["package_options"]:
                option_name = option["name"]
                
                packages.append({
                    "number": option_number,
                    "variant_name": variant_name,
                    "option_name": option_name,
                    "price": option["price"],
                    "code": option["package_option_code"],
                    "option_order": option["order"]
                })
                                
                print(f"   {option_number}. {option_name} - {price_currency} {option['price']}")
                
                option_number += 1
            
            if variant_number < len(package_variants):
                print("-------------------------------------------------------")
            variant_number += 1
        print("-------------------------------------------------------")

        print("00. Kembali ke menu utama")
        print("-------------------------------------------------------")
        pkg_choice = input("Pilih paket (nomor): ")
        if pkg_choice == "00":
            in_package_menu = False
            return None
        selected_pkg = next((p for p in packages if p["number"] == int(pkg_choice)), None)
        
        if not selected_pkg:
            print("Paket tidak ditemukan. Silakan masukan nomor yang benar.")
            continue
        
        is_done = show_package_details(api_key, tokens, selected_pkg["code"], is_enterprise, option_order=selected_pkg["option_order"])
        if is_done:
            in_package_menu = False
            return None
        else:
            continue
        
    return packages

def fetch_my_packages():
    api_key = AuthInstance.api_key
    tokens = AuthInstance.get_active_tokens()
    if not tokens:
        print("No active user tokens found.")
        pause()
        return None
    
    id_token = tokens.get("id_token")
    
    path = "api/v8/packages/quota-details"
    
    payload = {
        "is_enterprise": False,
        "lang": "en",
        "family_member_id": ""
    }
    
    print("Fetching my packages...")
    res = send_api_request(api_key, path, payload, id_token, "POST")
    if res.get("status") != "SUCCESS":
        print("Failed to fetch packages")
        print("Response:", res)
        pause()
        return None
    
    quotas = res["data"]["quotas"]
    
    clear_screen()
    print_box("📦 MY PACKAGES", Colors.BRIGHT_GREEN)
    print_colored("📱 Paket aktif yang Anda miliki", Colors.BRIGHT_WHITE)
    print_separator("═", 60, Colors.BRIGHT_GREEN)
    print()
    my_packages =[]
    num = 1
    for quota in quotas:
        quota_code = quota["quota_code"] # Can be used as option_code
        group_code = quota["group_code"]
        group_name = quota["group_name"]
        quota_name = quota["name"]
        family_code = "N/A"
        
        benefit_infos = []
        benefits = quota.get("benefits", [])
        if len(benefits) > 0:
            for benefit in benefits:
                benefit_id = benefit.get("id", "")
                name = benefit.get("name", "")
                data_type = benefit.get("data_type", "N/A")
                benefit_info = f"{Colors.DIM}  ─────────────────────────────────────────────────────{Colors.RESET}\n"
                benefit_info += f"  {Colors.BRIGHT_WHITE}ID{Colors.RESET}    : {Colors.DIM}{benefit_id}{Colors.RESET}\n"
                benefit_info += f"  {Colors.BRIGHT_CYAN}Name{Colors.RESET}  : {Colors.BRIGHT_WHITE}{name}{Colors.RESET}\n"
                benefit_info += f"  {Colors.BRIGHT_YELLOW}Type{Colors.RESET}  : {Colors.BRIGHT_MAGENTA}{data_type}{Colors.RESET}\n"
                

                remaining = benefit.get("remaining", 0)
                total = benefit.get("total", 0)

                if data_type == "DATA":
                    if remaining >= 1_000_000_000:
                        remaining_gb = remaining / (1024 ** 3)
                        remaining_str = f"{remaining_gb:.2f} GB"
                    elif remaining >= 1_000_000:
                        remaining_mb = remaining / (1024 ** 2)
                        remaining_str = f"{remaining_mb:.2f} MB"
                    elif remaining >= 1_000:
                        remaining_kb = remaining / 1024
                        remaining_str = f"{remaining_kb:.2f} KB"
                    else:
                        remaining_str = str(remaining)
                    
                    if total >= 1_000_000_000:
                        total_gb = total / (1024 ** 3)
                        total_str = f"{total_gb:.2f} GB"
                    elif total >= 1_000_000:
                        total_mb = total / (1024 ** 2)
                        total_str = f"{total_mb:.2f} MB"
                    elif total >= 1_000:
                        total_kb = total / 1024
                        total_str = f"{total_kb:.2f} KB"
                    else:
                        total_str = str(total)
                    
                    benefit_info += f"  {Colors.BRIGHT_GREEN}Kuota{Colors.RESET} : {Colors.BRIGHT_CYAN}{remaining_str}{Colors.RESET} / {Colors.DIM}{total_str}{Colors.RESET}"
                elif data_type == "VOICE":
                    benefit_info += f"  {Colors.BRIGHT_GREEN}Kuota{Colors.RESET} : {Colors.BRIGHT_CYAN}{remaining/60:.2f}{Colors.RESET} / {Colors.DIM}{total/60:.2f}{Colors.RESET} menit"
                elif data_type == "TEXT":
                    benefit_info += f"  {Colors.BRIGHT_GREEN}Kuota{Colors.RESET} : {Colors.BRIGHT_CYAN}{remaining}{Colors.RESET} / {Colors.DIM}{total}{Colors.RESET} SMS"
                else:
                    benefit_info += f"  {Colors.BRIGHT_GREEN}Kuota{Colors.RESET} : {Colors.BRIGHT_CYAN}{remaining}{Colors.RESET} / {Colors.DIM}{total}{Colors.RESET}"

                benefit_infos.append(benefit_info)
            
        
        print(f"fetching package no. {num} details...")
        package_details = get_package(api_key, tokens, quota_code)
        if package_details:
            family_code = package_details["package_family"]["package_family_code"]
        
        print_separator("═", 60, Colors.BRIGHT_CYAN)
        print(f"{Colors.BOLD}{Colors.BRIGHT_YELLOW}📦 PACKAGE {num}{Colors.RESET}")
        print(info_item("📋 Name", quota_name, Colors.BRIGHT_CYAN))
        print_colored("🎁 Benefits:", Colors.BRIGHT_GREEN)
        if len(benefit_infos) > 0:
            for bi in benefit_infos:
                print(bi)
            print(f"{Colors.DIM}  ─────────────────────────────────────────────────────{Colors.RESET}")
        print()
        print(info_item("👥 Group Name", group_name, Colors.BRIGHT_BLUE))
        print(info_item("🔢 Quota Code", quota_code, Colors.DIM))
        print(info_item("👨‍👩‍👧‍👦 Family Code", family_code, Colors.BRIGHT_YELLOW))
        print(info_item("🏷️ Group Code", group_code, Colors.DIM))
        
        my_packages.append({
            "number": num,
            "quota_code": quota_code,
        })
        
        num += 1
    
    print()
    print_separator("═", 60, Colors.BRIGHT_GREEN)
    print_colored("🔄 Rebuy package? Input package number to rebuy, or '00' to back.", Colors.BRIGHT_WHITE)
    print_colored("Choice: ", Colors.BRIGHT_CYAN, end="")
    choice = input("")
    if choice == "00":
        return None
    selected_pkg = next((pkg for pkg in my_packages if str(pkg["number"]) == choice), None)
    
    if not selected_pkg:
        print(error_msg("Paket tidak ditemukan. Silakan masukan nomor yang benar."))
        return None
    
    is_done = show_package_details(api_key, tokens, selected_pkg["quota_code"], False)
    if is_done:
        return None
        
    pause()
