from app.client.engsel import get_otp, submit_otp
from app.menus.util import clear_screen, pause
from app.service.auth import AuthInstance
from app.colors import *

def show_login_menu():
    clear_screen()
    print_box("🔐 LOGIN KE MY XL", Colors.BRIGHT_BLUE)
    print()
    print(menu_item("1", "Request OTP", "📱", Colors.BRIGHT_GREEN))
    print(menu_item("2", "Submit OTP", "🔑", Colors.BRIGHT_YELLOW))
    print(menu_item("99", "Tutup Aplikasi", "🚪", Colors.BRIGHT_RED))
    print()
    print_separator("═", 50, Colors.BRIGHT_CYAN)
    
def login_prompt(api_key: str):
    clear_screen()
    print_box("🔐 LOGIN KE MY XL", Colors.BRIGHT_BLUE)
    print()
    print_colored("📱 Masukan nomor XL (Contoh: 6281234567890):", Colors.BRIGHT_CYAN)
    print_colored("Nomor: ", Colors.BRIGHT_YELLOW, end="")
    phone_number = input("")

    if not phone_number.startswith("628") or len(phone_number) < 10 or len(phone_number) > 14:
        print(error_msg("Nomor tidak valid. Pastikan nomor diawali dengan '628' dan memiliki panjang yang benar."))
        return None

    try:
        subscriber_id = get_otp(phone_number)
        if not subscriber_id:
            return None
        print(success_msg("OTP Berhasil dikirim ke nomor Anda."))
        print()
        
        print_colored("🔑 Masukkan OTP yang telah dikirim: ", Colors.BRIGHT_YELLOW, end="")
        otp = input("")
        if not otp.isdigit() or len(otp) != 6:
            print(error_msg("OTP tidak valid. Pastikan OTP terdiri dari 6 digit angka."))
            pause()
            return None
        
        tokens = submit_otp(api_key, phone_number, otp)
        if not tokens:
            print(error_msg("Gagal login. Periksa OTP dan coba lagi."))
            pause()
            return None
        
        print(success_msg("Berhasil login!"))
        
        return phone_number, tokens["refresh_token"]
    except Exception as e:
        print(error_msg(f"Error login: {str(e)}"))
        pause()
        return None, None

def show_account_menu():
    clear_screen()
    AuthInstance.load_tokens()
    users = AuthInstance.refresh_tokens
    active_user = AuthInstance.get_active_user()
    
    # print(f"users: {users}")
    
    in_account_menu = True
    add_user = False
    while in_account_menu:
        clear_screen()
        if AuthInstance.get_active_user() is None or add_user:
            login_result = login_prompt(AuthInstance.api_key)
            if not login_result or len(login_result) != 2:
                print(error_msg("Gagal menambah akun. Silahkan coba lagi."))
                pause()
                continue
            
            number, refresh_token = login_result
            if not refresh_token:
                print(error_msg("Gagal menambah akun. Silahkan coba lagi."))
                pause()
                continue
            
            AuthInstance.add_refresh_token(int(number), refresh_token)
            AuthInstance.load_tokens()
            users = AuthInstance.refresh_tokens
            active_user = AuthInstance.get_active_user()
            
            
            if add_user:
                add_user = False
            continue
        
        print_box("👥 AKUN TERSIMPAN", Colors.BRIGHT_BLUE)
        print()
        if not users or len(users) == 0:
            print_colored("Tidak ada akun tersimpan.", Colors.BRIGHT_YELLOW)

        for idx, user in enumerate(users):
            is_active = active_user and user["number"] == active_user["number"]
            if is_active:
                print(f"{Colors.BOLD}{Colors.BRIGHT_GREEN}{idx + 1:>2}. {user['number']} {Colors.BG_GREEN}{Colors.BLACK} AKTIF {Colors.RESET}")
            else:
                print(f"{Colors.BRIGHT_WHITE}{idx + 1:>2}. {user['number']}")
        
        print()
        print_colored("🎮 PERINTAH:", Colors.BRIGHT_CYAN)
        print(menu_item("0", "Tambah Akun", "➕", Colors.BRIGHT_GREEN))
        print(menu_item("00", "Kembali ke Menu Utama", "🏠", Colors.BRIGHT_BLUE))
        print(menu_item("99", "Hapus Akun Aktif", "🗑️", Colors.BRIGHT_RED))
        print()
        print_colored("Masukan nomor akun untuk berganti.", Colors.BRIGHT_YELLOW)
        print_colored("Pilihan: ", Colors.BRIGHT_WHITE, end="")
        input_str = input("")
        if input_str == "00":
            in_account_menu = False
            return active_user["number"] if active_user else None
        elif input_str == "0":
            add_user = True
            continue
        elif input_str == "99":
            if not active_user:
                print(warning_msg("Tidak ada akun aktif untuk dihapus."))
                pause()
                continue
            print()
            print_colored(f"⚠️  Yakin ingin menghapus akun {active_user['number']}? (y/n): ", Colors.BRIGHT_YELLOW, end="")
            confirm = input("")
            if confirm.lower() == 'y':
                AuthInstance.remove_refresh_token(active_user["number"])
                # AuthInstance.load_tokens()
                users = AuthInstance.refresh_tokens
                active_user = AuthInstance.get_active_user()
                print(success_msg("Akun berhasil dihapus."))
                pause()
            else:
                print(info_msg("Penghapusan akun dibatalkan."))
                pause()
            continue
        elif input_str.isdigit() and 1 <= int(input_str) <= len(users):
            selected_user = users[int(input_str) - 1]
            return selected_user['number']
        else:
            print("Input tidak valid. Silahkan coba lagi.")
            pause()
            continue