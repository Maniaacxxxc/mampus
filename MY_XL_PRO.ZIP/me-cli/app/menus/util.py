import app.menus.banner as banner
from html.parser import HTMLParser
import os
import re
import textwrap
from app.colors import *

# Load banner but don't display in clear_screen
try:
    ascii_art = banner.load("https://me.mashu.lol/mebanner880.png", globals())
except:
    ascii_art = None

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    
    # Print colorized MY XL logo only (no old ASCII art)
    print(my_xl_logo())
    print_colored("🌟 MY XL CLI - Paket Internet & Pulsa 🌟", Colors.BOLD + Colors.BRIGHT_MAGENTA)
    print_separator("═", 60, Colors.BRIGHT_CYAN)
    print()

def pause():
    input("\nPress enter to continue...")

class HTMLToText(HTMLParser):
    def __init__(self, width=80):
        super().__init__()
        self.width = width
        self.result = []
        self.in_li = False

    def handle_starttag(self, tag, attrs):
        if tag == "li":
            self.in_li = True
        elif tag == "br":
            self.result.append("\n")

    def handle_endtag(self, tag):
        if tag == "li":
            self.in_li = False
            self.result.append("\n")

    def handle_data(self, data):
        text = data.strip()
        if text:
            if self.in_li:
                self.result.append(f"- {text}")
            else:
                self.result.append(text)

    def get_text(self):
        # Join and clean multiple newlines
        text = "".join(self.result)
        text = re.sub(r"\n\s*\n\s*\n+", "\n\n", text)
        # Wrap lines nicely
        return "\n".join(textwrap.wrap(text, width=self.width, replace_whitespace=False))

def display_html(html_text, width=80):
    parser = HTMLToText(width=width)
    parser.feed(html_text)
    return parser.get_text()