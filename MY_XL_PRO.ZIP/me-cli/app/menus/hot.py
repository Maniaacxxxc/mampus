"""
Hot Menu Module - Encrypted Version
MY XL CLI Application
"""
import base64
import zlib
import hashlib
import sys

# Encrypted hot menu data
_HOT_DATA = """FK8FvslTtHiXv/ut/EduCzprI+rUuN4WwNB1mdcnr5Ji96jUAokpUZqsDGOGsncuTZUGy9QrKnhrR+0m/3VbgJZblmXiLNX7/fvhFKY8kL4EHsXobUVhBEGi83eFzVaN4D4sLXMUvpHuDUy8n74CugNpuvZPsmuQwyNE962H3VZoMtxY7Vtw0L7/463lrW6ZYbC63yZMhX/g2dSSJ9gh/33xtzU1zN/p5cTGhKqxieqODaSQ9Gl9CSwQSLTja9S7fgK5Zld8deg7p2HMcG3UgGFQpRQJHWVVQBacDpIaNki30ceVrJED1wr1IdWG0H0auOXf7aiiIejZL3NIN+fuskJ+8UsIxVYFxCEmPQmdatWJdl9Xs7xPQJGLz00ZRHtUiWBn1xX0SeeU24ReVpLaXOaNUWTf9AtwvVX2qw01CzCjxjGk/aEI55nanlWEGmjaB6FPWhs4CTmm/Sr7pKHiW4WWNbvV1E+7+u+eOy7ppg+/MBM9noDIpMXmz0vpHa0pwu7RYQCTXAz9nR1YIimxPOhSxK1H//7DU+tjsNfSxn2fPqQDnzXrmFKOhqtKEjYDz356hIoYTG3xnsdbl3xj02OuvL9byIomo9nLHV03xBWBmGCcFSscF4k4uBlYGSyr0YJqIUqYb0rKOSyMfDv1ABqy7UQqr5vhrvT9I6lLGNw+nJBUnw+6IxnhoEkqdKFd+k5Z0JdNYXud6KlvCExlpj3RVPFZf7nG2gMEwrWMdZXLpoHGrLHdWE1Zka2bf0UjpTPdREaOr9JbOwqXwcQNF/7u2Gpsza6xl8MIxfjqSLQjqVKaw4klSvE6bky/uUsjt6MGyGo8uD6AjOx5ftmtPY8SKzPHzqoRRr4+uy6xYsb/pHtYrMSeTUryi8FHZaWwgSU30bjA2EARpP1ZyVORXyTUtoVKDGuWg+q28JGSQJtnLcrNj+odw3Q/rXUPug7eWUnu1+gJEqXKfPVs6ilTP1UEmBDWLWy58oa/0YpVWKL5nhyeBNyzUIprHMFnLBICRoSuBgyWLoydHvdjQnBx050TMA2oowxSBBbfs8ceLQPaxaf7e8aM+SdAncXUBJ5IqlmKWLe69bUq/OrGyKsxD4qpGWhFOi17JxCSzqOQSJZDMslVZdTi9Jnr5TMsuogyXVi0a4694er6YuG8VJWkswnznBfVs1UaWI+micQJhfD+tVdoZMcVIypvBKVmf5yDDkrD+/kHZQsrbDnJMUbIeN3VHKZLUQb2hFRFV8D3sUG7rW2/8JPBEjrbdaevY4Xz1WSrxa889DFDMwX3UeGHkDd4JGaC+D0Fq9CvNrCSCZE88FmC2/V+BLfuFRG1dtPumOFNUNRpGpeFCi+bSPpAJnAghngPKHxOj80XqvMMQXlkwpoWejTE17VfLAnZOWRCHSFxTM1VYWr5QJcsLw+cmUPVGKEqDt3bjWk3fLbWIm8ETUtUpWJvbdYLbigSD2N0+PESA5Yuk3RFALVcGGXav7wUg7YPfolb+h0753+ONm42WESaFJUyZXSOHC3eosCArAbgU5Q7sbnPIjwfF0FXGyf5qtihR1VZ0NZKXyIBklVzVz5fYlfCJT00JznrfRN4XX4huNSfOuUeJTQJZviBeyFxysnQqiwAY6j5ZB/G+XnyQHBRNvbUTF2C+K6dk4U6gbQWGvIeED21kOsWu9BFbZI/hpl8C7Ndrl99eNdxnNsZyzO/xZiupX6poptNWhsZhIcaDneV2+63FJwoyDpx9exer/OpRftlr8IQ2MAdeUEHuYv+S87dkF7iZLkFRP+IbbBF9veIu/U5wMrmQgMi3L2XSDFhYup8jt2rTQ6kggc/fMsjLcQqsjKBHC8sCDowFTVewMRWptSOkAGt+f6YPgKaow/F8n90DiL2yNThaKjaNYrgfb13x0t4qTK0XmK9gaaqCYjp23gbvpaBrXudWnWH6nXCDzJgWROly34gyooAT6M99uUVM8SdAYVfDqQwj9Gec+7nxvwOB/Zxj+Cc4dsGiUXlYIS3QDiQCrEBYtHNWZ6z363aafftUPa/CIF4OP615ygCehozRf5U+wNU/qVzlmwjqeibA9fm6J92qkNQ5e6pylPJfDeCQXvfkFqyHndm5pqcODEIqlhQWnsqsZk/ioZVAWfwU8WZ/8IItrvBrrAWUVAYdDErRhWBySN2ldJrGWcFqatKOcz5Yuu0nes1XSYxma/z6Z9NJH52i7knxrPjN6uBy/I6O8m42NhS5mQy9MnfLxhRt5pJo7wmgT7tTTek7x45e9H80PNq9giZ08ODdxIml6X5UySOishG2hJSAM4o2f92TX/vcTmVXbwFA4nyc2LtdrVDOy2VNsV7nR3YUB4QGvhkAYfHhvJpom/V1WekH727AsEWYEgHJp5Qx/1o+nvPGWlAyGOyP584YsBJ/NZsxWzMaINR44zqPgChxaz9B7/bGfxieN4+IGJzj6PsERau9tjRUtprpGHePqgKa1PBmRgIdn+HLbaQeqJsy1kML+0PBoqLd9rPTzioeKnlUuuDfBwqEUHnVbzTMwYpclHZlk9szT2oPo33jKmY3nJTMxbVBGXIgp3uKDK3EdxQWx9TTnFw0PoD1NZ55rV5QtBsRxdoWyooW9sSGv9ZdqsDa5rZ9eflJYaN3s0ziVGP1G4+u31Akae7SvxpGrX+VJgZKB5yFZ8N12IQiklH/JpaJFBNuPsxWjO1DcjcsAhe3xI2jWePNebRU4MjIi2u+eLk3eGEpw6BUZLIBShnmY0waWifkhuSue9b3J1Gt1Go7g+YtJwHW+JSR2EiyxE="""

def _get_decryption_key():
    """Get decryption key"""
    return hashlib.md5("HotMenuXL2025Secret".encode()).digest()

def _decrypt_hot_module():
    """Decrypt and load hot module"""
    try:
        # Get key
        key = _get_decryption_key()
        
        # Base64 decode
        encrypted_data = base64.b64decode(_HOT_DATA.encode('ascii'))
        
        # XOR decrypt
        key_len = len(key)
        decrypted = bytes([encrypted_data[i] ^ key[i % key_len] for i in range(len(encrypted_data))])
        
        # Decompress
        original_code = zlib.decompress(decrypted).decode('utf-8')
        
        # Execute dalam module context
        module_globals = {}
        exec(original_code, module_globals)
        
        # Export functions
        return module_globals
        
    except Exception as e:
        print(f"❌ Hot module decryption error: {e}")
        sys.exit(1)

# Load encrypted module
_hot_module = _decrypt_hot_module()

# Export all functions dari original module
show_hot_menu = _hot_module.get('show_hot_menu')
show_hot_menu2 = _hot_module.get('show_hot_menu2')

# Pastikan functions tersedia
if not show_hot_menu or not show_hot_menu2:
    print("❌ Error: Hot menu functions tidak ditemukan")
    sys.exit(1)
