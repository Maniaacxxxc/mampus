#!/usr/bin/env python3
"""
Color utilities for terminal output
"""

class Colors:
    # Reset
    RESET = '\033[0m'
    
    # Text colors
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    
    # Bright colors
    BRIGHT_BLACK = '\033[90m'
    BRIGHT_RED = '\033[91m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_MAGENTA = '\033[95m'
    BRIGHT_CYAN = '\033[96m'
    BRIGHT_WHITE = '\033[97m'
    
    # Background colors
    BG_BLACK = '\033[40m'
    BG_RED = '\033[41m'
    BG_GREEN = '\033[42m'
    BG_YELLOW = '\033[43m'
    BG_BLUE = '\033[44m'
    BG_MAGENTA = '\033[45m'
    BG_CYAN = '\033[46m'
    BG_WHITE = '\033[47m'
    
    # Text styles
    BOLD = '\033[1m'
    DIM = '\033[2m'
    ITALIC = '\033[3m'
    UNDERLINE = '\033[4m'
    BLINK = '\033[5m'
    REVERSE = '\033[7m'
    STRIKETHROUGH = '\033[9m'

def colorize(text, color):
    """Add color to text"""
    return f"{color}{text}{Colors.RESET}"

def print_colored(text, color=Colors.WHITE, end='\n'):
    """Print colored text"""
    print(colorize(text, color), end=end)

def print_gradient_text(text, start_color, end_color):
    """Print text with gradient effect (simplified)"""
    print(colorize(text, start_color))

def my_xl_logo():
    """Return colorized MY XL logo"""
    logo = f"""
{Colors.BOLD}{Colors.BRIGHT_YELLOW}██████████████████████████████████████████████████████████{Colors.RESET}
{Colors.BOLD}{Colors.BG_BLUE}{Colors.BRIGHT_WHITE}     ███╗   ███╗██╗   ██╗     {Colors.RESET}{Colors.BG_RED}{Colors.BRIGHT_WHITE}     ██╗  ██╗██╗      {Colors.RESET}
{Colors.BOLD}{Colors.BG_BLUE}{Colors.BRIGHT_WHITE}     ████╗ ████║╚██╗ ██╔╝     {Colors.RESET}{Colors.BG_RED}{Colors.BRIGHT_WHITE}     ╚██╗██╔╝██║      {Colors.RESET}
{Colors.BOLD}{Colors.BG_BLUE}{Colors.BRIGHT_WHITE}     ██╔████╔██║ ╚████╔╝      {Colors.RESET}{Colors.BG_RED}{Colors.BRIGHT_WHITE}      ╚███╔╝ ██║      {Colors.RESET}
{Colors.BOLD}{Colors.BG_BLUE}{Colors.BRIGHT_WHITE}     ██║╚██╔╝██║  ╚██╔╝       {Colors.RESET}{Colors.BG_RED}{Colors.BRIGHT_WHITE}      ██╔██╗ ██║      {Colors.RESET}
{Colors.BOLD}{Colors.BG_BLUE}{Colors.BRIGHT_WHITE}     ██║ ╚═╝ ██║   ██║        {Colors.RESET}{Colors.BG_RED}{Colors.BRIGHT_WHITE}      ██╔╝ ██╗███████╗ {Colors.RESET}
{Colors.BOLD}{Colors.BG_BLUE}{Colors.BRIGHT_WHITE}     ╚═╝     ╚═╝   ╚═╝        {Colors.RESET}{Colors.BG_RED}{Colors.BRIGHT_WHITE}      ╚═╝  ╚═╝╚══════╝ {Colors.RESET}
{Colors.BOLD}{Colors.BRIGHT_YELLOW}██████████████████████████████████████████████████████████{Colors.RESET}
"""
    return logo

def simple_my_xl_logo():
    """Return simple colorized MY XL logo"""
    return f"{Colors.BOLD}{Colors.BG_BLUE}{Colors.BRIGHT_WHITE}  MY  {Colors.RESET} {Colors.BOLD}{Colors.BG_RED}{Colors.BRIGHT_WHITE}  XL  {Colors.RESET}"

def print_separator(char="═", length=60, color=Colors.BRIGHT_CYAN):
    """Print colored separator"""
    print_colored(char * length, color)

def print_box(text, color=Colors.BRIGHT_YELLOW):
    """Print text in a colored box"""
    length = len(text) + 4
    print_colored("┌" + "─" * (length - 2) + "┐", color)
    print_colored(f"│ {text} │", color)
    print_colored("└" + "─" * (length - 2) + "┘", color)

def menu_item(number, text, icon="", color=Colors.BRIGHT_WHITE):
    """Format menu item with color"""
    return f"{Colors.BOLD}{Colors.BRIGHT_CYAN}{number:>2}.{Colors.RESET} {icon} {colorize(text, color)}"

def info_item(label, value, label_color=Colors.BRIGHT_YELLOW, value_color=Colors.BRIGHT_WHITE):
    """Format info item with colors"""
    return f"{colorize(label + ':', label_color)} {colorize(str(value), value_color)}"

def success_msg(text):
    """Format success message"""
    return f"{Colors.BOLD}{Colors.BRIGHT_GREEN}✓{Colors.RESET} {colorize(text, Colors.BRIGHT_GREEN)}"

def error_msg(text):
    """Format error message"""
    return f"{Colors.BOLD}{Colors.BRIGHT_RED}✗{Colors.RESET} {colorize(text, Colors.BRIGHT_RED)}"

def warning_msg(text):
    """Format warning message"""
    return f"{Colors.BOLD}{Colors.BRIGHT_YELLOW}⚠{Colors.RESET} {colorize(text, Colors.BRIGHT_YELLOW)}"

def info_msg(text):
    """Format info message"""
    return f"{Colors.BOLD}{Colors.BRIGHT_CYAN}ℹ{Colors.RESET} {colorize(text, Colors.BRIGHT_CYAN)}"