"""
Color utility module for terminal output
"""

from colorama import Fore, Back, Style, init

# Initialize colorama
init(autoreset=True)

class Colors:
    # Text colors
    RED = Fore.RED
    GREEN = Fore.GREEN  
    YELLOW = Fore.YELLOW
    BLUE = Fore.BLUE
    MAGENTA = Fore.MAGENTA
    CYAN = Fore.CYAN
    WHITE = Fore.WHITE
    BLACK = Fore.BLACK
    LIGHTRED = Fore.LIGHTRED_EX
    LIGHTGREEN = Fore.LIGHTGREEN_EX
    LIGHTYELLOW = Fore.LIGHTYELLOW_EX
    LIGHTBLUE = Fore.LIGHTBLUE_EX
    LIGHTMAGENTA = Fore.LIGHTMAGENTA_EX
    LIGHTCYAN = Fore.LIGHTCYAN_EX
    
    # Background colors  
    BG_RED = Back.RED
    BG_GREEN = Back.GREEN
    BG_YELLOW = Back.YELLOW
    BG_BLUE = Back.BLUE
    BG_MAGENTA = Back.MAGENTA
    BG_CYAN = Back.CYAN
    BG_WHITE = Back.WHITE
    BG_BLACK = Back.BLACK
    
    # Styles
    BOLD = Style.BRIGHT
    DIM = Style.DIM
    RESET = Style.RESET_ALL

def colored_text(text, color=Colors.WHITE, bg=None, style=None):
    """Apply color and style to text"""
    result = ""
    if style:
        result += style
    if bg:
        result += bg
    result += color + text + Colors.RESET
    return result

def create_box(content, width=55, color=Colors.CYAN, title=None):
    """Create a simple professional box around content"""
    lines = content.split('\n')
    
    box = ""
    
    # Top border
    if title:
        box += colored_text("┌─ " + title + " " + "─" * (width - len(title) - 4) + "┐", color) + "\n"
    else:
        box += colored_text("┌" + "─" * (width - 2) + "┐", color) + "\n"
    
    # Content lines
    for line in lines:
        if len(line) <= width - 4:
            box += colored_text("│ ", color) + line.ljust(width - 4) + colored_text(" │", color) + "\n"
        else:
            # Split long lines
            words = line.split()
            current_line = ""
            for word in words:
                if len(current_line + word) <= width - 4:
                    current_line += word + " "
                else:
                    box += colored_text("│ ", color) + current_line.ljust(width - 4) + colored_text(" │", color) + "\n"
                    current_line = word + " "
            if current_line:
                box += colored_text("│ ", color) + current_line.ljust(width - 4) + colored_text(" │", color) + "\n"
    
    # Bottom border
    box += colored_text("└" + "─" * (width - 2) + "┘", color)
    
    return box

def create_menu_item(number, title, description=None, price=None, width=55):
    """Create a simple formatted menu item"""
    content = ""
    
    # Number and title
    if description or price:
        content += colored_text(f"[{number}]", Colors.CYAN) + " " + title
        if description:
            content += f"\n     {description}"
        if price:
            content += f"\n     Harga: " + colored_text(price, Colors.GREEN)
    else:
        content += colored_text(f"[{number}]", Colors.CYAN) + f" {title}"
    
    return content

def create_logo():
    """Create MY-XL logo similar to the screenshot"""
    logo = ""
    
    # Simple MY-XL Logo with colors like screenshot
    logo += colored_text("███╗   ███╗██╗   ██╗", Colors.BLUE, style=Colors.BOLD) + "      "
    logo += colored_text("██╗  ██╗██╗     ", Colors.RED, style=Colors.BOLD) + "\n"
    
    logo += colored_text("████╗ ████║╚██╗ ██╔╝", Colors.BLUE, style=Colors.BOLD) + "      "
    logo += colored_text("╚██╗██╔╝██║     ", Colors.RED, style=Colors.BOLD) + "\n"
    
    logo += colored_text("██╔████╔██║ ╚████╔╝ ", Colors.BLUE, style=Colors.BOLD) + " █████╗ "
    logo += colored_text("╚███╔╝ ██║     ", Colors.RED, style=Colors.BOLD) + "\n"
    
    logo += colored_text("██║╚██╔╝██║  ╚██╔╝  ", Colors.BLUE, style=Colors.BOLD) + " ╚════╝ "
    logo += colored_text("██╔██╗ ██║     ", Colors.RED, style=Colors.BOLD) + "\n"
    
    logo += colored_text("██║ ╚═╝ ██║   ██║   ", Colors.BLUE, style=Colors.BOLD) + "        "
    logo += colored_text("██╔╝ ██╗███████╗", Colors.RED, style=Colors.BOLD) + "\n"
    
    logo += colored_text("╚═╝     ╚═╝   ╚═╝   ", Colors.BLUE, style=Colors.BOLD) + "        "
    logo += colored_text("╚═╝  ╚═╝╚══════╝", Colors.RED, style=Colors.BOLD) + "\n"
    
    # Subtitle with stars
    logo += "\n" + colored_text("⭐ MY XL CLI - Paket Internet & Pulsa ⭐", Colors.MAGENTA, style=Colors.BOLD) + "\n"
    logo += colored_text("═" * 55, Colors.CYAN) + "\n"
    
    return logo