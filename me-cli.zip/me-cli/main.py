from dotenv import load_dotenv

load_dotenv() 

import sys
from app.menus.util import clear_screen, pause
from app.client.engsel import *
from app.client.engsel2 import get_tiering_info
from app.menus.payment import show_transaction_history
from app.service.auth import AuthInstance
from app.menus.bookmark import show_bookmark_menu
from app.menus.account import show_account_menu
from app.menus.package import fetch_my_packages, get_packages_by_family
from app.menus.hot import show_hot_menu, show_hot_menu2
from app.service.sentry import enter_sentry_mode
from app.menus.purchase import purchase_by_family
from app.colors import Colors, colored_text, create_box, create_menu_item

WIDTH = 55

def show_main_menu(profile):
    clear_screen()
    
    # Profile info box like in screenshot
    expired_at_dt = datetime.fromtimestamp(profile["balance_expired_at"]).strftime("%Y-%m-%d %H:%M:%S")
    
    print(create_box("INFORMASI AKUN", WIDTH, Colors.GREEN))
    print("")
    print(f"📱 {colored_text('Nomor:', Colors.CYAN)} {profile['number']}")
    print(f"📋 {colored_text('Tipe:', Colors.CYAN)} {profile['subscription_type']}")
    print(f"💰 {colored_text('Pulsa:', Colors.CYAN)} Rp {profile['balance']}")
    print(f"🎯 {colored_text('Poin:', Colors.CYAN)} {profile['point_info']}")
    print(f"⏰ {colored_text('Masa Aktif:', Colors.CYAN)} {expired_at_dt}")
    print("")
    
    # Menu like in screenshot
    print(create_box("MENU UTAMA", WIDTH, Colors.BLUE))
    print("")
    print(f"1. 👤 {colored_text('Login/Ganti Akun', Colors.WHITE)}")
    print(f"2. 📦 {colored_text('Lihat Paket Saya', Colors.WHITE)}")
    print(f"3. 🔥 {colored_text('Beli Paket', Colors.YELLOW)} 🔥 {colored_text('HOT', Colors.RED)} 🔥")
    print(f"4. 🔥 {colored_text('Beli Paket', Colors.YELLOW)} 🔥 {colored_text('HOT-2', Colors.RED)} 🔥")
    print(f"5. 🏷️ {colored_text('Beli Paket Family Code', Colors.MAGENTA)}")
    print(f"6. 📊 {colored_text('Riwayat Transaksi', Colors.WHITE)}")
    print(f"7. 🧪 {colored_text('[Test] Purchase Family Code', Colors.YELLOW)}")
    print("")
    print(f"00. ⭐ {colored_text('Bookmark Paket', Colors.YELLOW)}")
    print(f"99. 🚪 {colored_text('Tutup Aplikasi', Colors.RED)}")
    print("")
    print(colored_text("═" * WIDTH, Colors.CYAN))

show_menu = True
def main():
    
    while True:
        active_user = AuthInstance.get_active_user()

        # Logged in
        if active_user is not None:
            balance = get_balance(AuthInstance.api_key, active_user["tokens"]["id_token"])
            balance_remaining = balance.get("remaining")
            balance_expired_at = balance.get("expired_at")
            
            profile_data = get_profile(AuthInstance.api_key, active_user["tokens"]["access_token"], active_user["tokens"]["id_token"])
            sub_id = profile_data["profile"]["subscriber_id"]
            sub_type = profile_data["profile"]["subscription_type"]
            
            point_info = "Points: N/A | Tier: N/A"
            
            if sub_type == "PREPAID":
                tiering_data = get_tiering_info(AuthInstance.api_key, active_user["tokens"])
                tier = tiering_data.get("tier", 0)
                current_point = tiering_data.get("current_point", 0)
                point_info = f"Points: {current_point} | Tier: {tier}"
            
            profile = {
                "number": active_user["number"],
                "subscriber_id": sub_id,
                "subscription_type": sub_type,
                "balance": balance_remaining,
                "balance_expired_at": balance_expired_at,
                "point_info": point_info
            }

            show_main_menu(profile)

            choice = input(colored_text("⚡ Pilih menu: ", Colors.RED))
            if choice == "1":
                selected_user_number = show_account_menu()
                if selected_user_number:
                    AuthInstance.set_active_user(selected_user_number)
                else:
                    print(colored_text("❌ No user selected or failed to load user.", Colors.RED))
                continue
            elif choice == "2":
                fetch_my_packages()
                continue
            elif choice == "3":
                show_hot_menu()
            elif choice == "4":
                show_hot_menu2()
            elif choice == "5":
                family_code = input("Enter family code (or '99' to cancel): ")
                if family_code == "99":
                    continue
                get_packages_by_family(family_code)
            elif choice == "6":
                show_transaction_history(AuthInstance.api_key, active_user["tokens"])
            elif choice == "7":
                family_code = input("Enter family code (or '99' to cancel): ")
                if family_code == "99":
                    continue
                use_decoy = input("Use decoy package? (y/n): ").lower() == 'y'
                pause_on_success = input("Pause on each successful purchase? (y/n): ").lower() == 'y'
                purchase_by_family(family_code, use_decoy, pause_on_success)
            elif choice == "00":
                show_bookmark_menu()
            elif choice == "99":
                print(colored_text("👋 Exiting the application.", Colors.LIGHTYELLOW))
                sys.exit(0)
            elif choice == "t":
                res = get_package(
                    AuthInstance.api_key,
                    active_user["tokens"],
                    ""
                )
                print(json.dumps(res, indent=2))
                input("Press Enter to continue...")
                pass
            elif choice == "s":
                enter_sentry_mode()
            else:
                print(colored_text("❌ Invalid choice. Please try again.", Colors.RED))
                pause()
        else:
            # Not logged in
            selected_user_number = show_account_menu()
            if selected_user_number:
                AuthInstance.set_active_user(selected_user_number)
            else:
                print(colored_text("❌ No user selected or failed to load user.", Colors.RED))

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(colored_text("\n👋 Exiting the application.", Colors.LIGHTYELLOW))
    # except Exception as e:
    #     print(f"An error occurred: {e}")
